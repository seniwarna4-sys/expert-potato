sh ${0%/*}/noop.sh
am start -a AxManager.TOAST -e text "bBoost Service Now Running [ Installed ]"
