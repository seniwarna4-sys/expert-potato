[ -n "$(pgrep -f noop.sh)" ] && echo "bBoost Service is running" || echo "bBoost not running"

DIR=$(cd "$(dirname "$0")" && pwd)
CONFIG_FILE="$DIR/bin/config.ini"
read_config() {
   while IFS='=' read -r lowkey value; do
      [ -z "$lowkey" ] || [ "${lowkey###}" != "$lowkey" ] && continue
      lowkey=$(echo "$lowkey" | tr -d '[:space:]')
      case "$lowkey" in
         game) game="$(echo "$value" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')" ;;
         exapp) exapp="$(echo "$value" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')" ;;
         *)    value=$(echo "$value" | tr -d '[:space:]') ;;
      esac
   done < "$CONFIG_FILE"
}
read_config

echo "
This Plugin created for performance and daily mode adapt while gaming or idle [ might consume more battery level and cause heat up ]

listed game : $game

if your game wasnt in Listed game contact me

Feedback or error
@Brains82"