ls /sdcard/Btool >/dev/null || mkdir /sdcard/Btool
cp $MODPATH/Prismatic_Slime.png /sdcard/Btool

ls /sdcard/Btool/bin/config.ini || cp -r $MODPATH/bin /sdcard/Btool