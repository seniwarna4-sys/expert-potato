nice -n 19 cmd notification post --large-icon /sdcard/Btool/Prismatic_Slime.png \
 -S bigtext -t "Bnoop - Boost" note "has been Uninstalled" > /dev/null

 am start -a AxManager.TOAST -e text "bBoost Service has Been Stopped [ Uninstalled ]"